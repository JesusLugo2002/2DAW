<template>
    <h1>Tienda</h1>
</template>