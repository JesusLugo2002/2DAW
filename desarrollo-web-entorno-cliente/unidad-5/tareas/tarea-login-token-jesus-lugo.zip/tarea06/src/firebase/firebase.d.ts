declare module '@/firebase/firebase' {
  const firebase: any // o el tipo que corresponda
  export default firebase
}
